import numpy as np

# Kmeans re implementation

class Centroid:
    def __init__(self, color):
        self.data = color
        self.neighbors = np.empty([0,3])
    
    def update_color(self):
        if len(self.neighbors) == 0:
            self.data = np.array([-255,-255,-255])
        self.data = np.mean(self.neighbors, axis=0)

    def get_dist(self, t_color):
        dist = np.linalg.norm(self.data - t_color)
        return dist
    
    def add_neighbor(self, color):
        self.neighbors = np.append(self.neighbors, color.reshape([1,-1]), axis=0)
    
    def clean_neighbor(self):
        self.neighbors = np.empty([0,3])
    
    def get_data(self):
        return self.data.astype(np.int16).tolist(), len(self.neighbors)
    
def random_selected_pixel_with_mask(img, mask=None, select_n=4):
    if mask.all() == None:
        mask = np.ones_like(img[:,:,0])
    if len(mask.shape) == 3:
        mask = mask[:,:,0]
    if len(np.unique(mask)) != 2:
        mask = np.where(mask<127, 0, 1)

    img_flat = img.reshape([-1,3])
    mask_flat = mask.flatten()

    selected_colors = np.array([])

    count = 0
    while(len(np.unique(selected_colors, axis=0)) != select_n):
        selected_pixels = np.random.choice(np.where(mask_flat == 1)[0], select_n, replace=False)    
        selected_colors = img_flat[selected_pixels]
        
        count += 1

        if count >= 30:
            return np.array([[0,0,0],[255,0,0],[0,255,0],[0,0,255]])

    return selected_colors

def color_extraction(img, mask=None, n_cluster=4, epochs = 1):
    if mask is None:
        mask = np.ones_like(img) * 255
        
    selected_colors = random_selected_pixel_with_mask(img, mask, n_cluster)
    k_map = {idx:Centroid(color) for idx, color in enumerate(selected_colors)}
    img = img.reshape([-1,3])

    result = []
    for epoch in range(epochs):
        for color in img:
            closest_k = np.argmin([k_map[k].get_dist(color) for k in range(n_cluster)])
            k_map[closest_k].add_neighbor(color)

        for k in range(n_cluster):
            k_map[k].update_color()

            if epoch == epochs-1:
                color, num_pix = k_map[k].get_data()
                result.append((color, num_pix/len(img)))
            else:
                k_map[k].clean_neighbor()

    result = sorted(result, key=lambda x:x[1], reverse=True)

    color_result = []
    percentage = []
    for cur in result:
        color_result.append(cur[0])
        percentage.append(cur[1])

    return [color_result, percentage]


def color_normalization(color_arr, scaling = True, type="rgb", only_scale=False):

    color_arr = np.array(color_arr).astype(np.float32)

    if type == "rgb":
        mean = np.array([0.485, 0.456, 0.406])
        std = np.array([0.229, 0.224, 0.225])
        scale = np.array([255.0, 255.0, 255.0])
    elif type == "hsv":
        mean = np.array([0.314 , 0.3064, 0.553])
        std = np.array([0.2173, 0.2056, 0.2211])
        scale = np.array([179.0, 255.0, 255.0])
        
    arr_shape_length = len(color_arr.shape)    
    new_shape = [1]*arr_shape_length
    new_shape[arr_shape_length-1] = -1

    mean = mean.reshape(new_shape)
    std = std.reshape(new_shape)
    scale = scale.reshape(new_shape)

    if scaling == True:
        color_arr /= scale

    if only_scale == True:
        return color_arr
    
    return (color_arr - mean)/std


def color_normalization_restore(color_arr, scaling = True, type="rgb"):
    color_arr = np.array(color_arr).astype(np.float32)

    if type == "rgb":
        mean = np.array([0.485, 0.456, 0.406])
        std = np.array([0.229, 0.224, 0.225])
        scale = np.array([255.0, 255.0, 255.0])
    elif type == "hsv":
        mean = np.array([0.314 , 0.3064, 0.553])
        std = np.array([0.2173, 0.2056, 0.2211])
        scale = np.array([179.0, 255.0, 255.0])
        
    arr_shape_length = len(color_arr.shape)
    new_shape = [1]*arr_shape_length
    new_shape[arr_shape_length-1] = -1
 
    mean = mean.reshape(new_shape)
    std = std.reshape(new_shape)
    scale = scale.reshape(new_shape)

    restored_arr = color_arr * std + mean

    if scaling == True:
        restored_arr *= scale

    return restored_arr


def rgb_to_hex(rgb):
    return '#%02x%02x%02x' % (int(rgb[0]), int(rgb[1]), int(rgb[2]))

def colors_to_hex(colors):
    colors = list(colors)
    return [rgb_to_hex(color) for color in colors]
